// Product data storage
let products = [];

// DOM elements
const nameInput = document.getElementById('product-name');
const priceInput = document.getElementById('product-price');
const ratingInput = document.getElementById('product-rating');
const addProductButton = document.getElementById('add-product');
const priceGraphContainer = document.querySelector('#price-graph .bars');
const ratingGraphContainer = document.querySelector('#rating-graph .bars');
const sortPriceButton = document.getElementById('sort-price');
const sortRatingButton = document.getElementById('sort-rating');

// Function to create a bar
function createBar(label, value, maxValue, color) {
    const barWrapper = document.createElement('div');
    barWrapper.classList.add('bar');

    const barLabel = document.createElement('div');
    barLabel.textContent = label;
    barLabel.classList.add('bar-label');

    const barVisual = document.createElement('div');
    barVisual.classList.add('bar-visual');
    barVisual.style.width = `${(value / maxValue) * 100}%`;
    barVisual.style.backgroundColor = color;

    barWrapper.appendChild(barLabel);
    barWrapper.appendChild(barVisual);

    return barWrapper;
}

// Function to update graphs
function updateGraphs() {
    // Clear existing bars
    priceGraphContainer.innerHTML = '';
    ratingGraphContainer.innerHTML = '';

    // Get maximum values for scaling
    const maxPrice = Math.max(...products.map(p => p.price), 1); // Avoid division by 0
    const maxRating = 5; // Fixed rating scale

    // Create bars for the price graph
    products.forEach(product => {
        const bar = createBar(product.name, product.price, maxPrice, '#2196f3');
        priceGraphContainer.appendChild(bar);
    });

    // Create bars for the rating graph
    products.forEach(product => {
        const bar = createBar(product.name, product.rating, maxRating, '#ff9800');
        ratingGraphContainer.appendChild(bar);
    });
}

// Event listener to add a product
addProductButton.addEventListener('click', () => {
    const name = nameInput.value.trim();
    const price = parseFloat(priceInput.value);
    const rating = parseFloat(ratingInput.value);

    if (!name || isNaN(price) || isNaN(rating) || rating < 1 || rating > 5) {
        alert('Please enter valid product details (Rating must be between 1 and 5)!');
        return;
    }

    // Add the product to the list
    products.push({ name, price, rating });

    // Clear input fields
    nameInput.value = '';
    priceInput.value = '';
    ratingInput.value = '';

    // Update the graphs
    updateGraphs();
});

// Event listener to sort by price
sortPriceButton.addEventListener('click', () => {
    products.sort((a, b) => a.price - b.price);
    updateGraphs();
});

// Event listener to sort by rating
sortRatingButton.addEventListener('click', () => {
    products.sort((a, b) => a.rating - b.rating);
    updateGraphs();
});
